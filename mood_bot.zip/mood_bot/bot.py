import telebot
from datetime import datetime, timedelta
from config import TOKEN, main_kb, user_state, get_mood_keyboard, get_work_keyboard, get_sleep_keyboard, get_comment_keyboard
from database import db

bot = telebot.TeleBot(TOKEN)
def send_msg(chat_id, text, keyboard=None):
    if keyboard:
        bot.send_message(chat_id, text, reply_markup=keyboard, parse_mode='Markdown')
    else:
        bot.send_message(chat_id, text, parse_mode='Markdown')

@bot.message_handler(commands=['start', 'help'])
def start(msg):
    text = "📊 Бот для анализа настроения\n\nВот что я умею:\n\n📝 /add - записать как прошёл день\n📊 /stats - посмотреть статистику за неделю\n📈 /analytics - подробный анализ (лучшие дни, влияние сна и работы)\n💡 /insights - полезные советы и выводы\n📜 /history - посмотреть что ты записывал раньше\n🗑 /clear - удалить все записи"
    send_msg(msg.chat.id, text, main_kb)

@bot.message_handler(commands=['add'])
@bot.message_handler(func=lambda m: m.text == "📝 Записать свой день")
def ask_mood(msg):
    user_state[msg.chat.id] = {'step': 'mood', 'data': {}, 'waiting_for': None}
    send_msg(msg.chat.id, "Оцени своё настроение от 1 до 5:", get_mood_keyboard())

@bot.callback_query_handler(func=lambda call: call.data.startswith('mood_'))
def get_mood(call):
    uid = call.message.chat.id
    mood_value = int(call.data.split('_')[1])
    user_state[uid]['data']['mood'] = mood_value
    user_state[uid]['step'] = 'work'
    
    bot.edit_message_text("Понял. Теперь сколько часов работал?", uid, call.message.message_id)
    send_msg(uid, "Выбери или введи своё:", get_work_keyboard())


@bot.message_handler(func=lambda m: m.chat.id in user_state and user_state[m.chat.id]['step'] == 'work')
def get_work(msg):
    uid = msg.chat.id
    text = msg.text.strip()
    

    if text == "Другое":
        user_state[uid]['waiting_for'] = 'work_custom'
        send_msg(uid, "Напиши сколько часов (например 3.5):")
        return
    

    try:
        value = float(text)
        user_state[uid]['data']['work_hours'] = value
        user_state[uid]['step'] = 'sleep'
        user_state[uid]['waiting_for'] = None
        send_msg(uid, "А сколько часов спал?", get_sleep_keyboard())
    except:
        send_msg(uid, "Ошибка! Нужно написать число, например 8 или 7.5")


@bot.message_handler(func=lambda m: m.chat.id in user_state and user_state[m.chat.id].get('waiting_for') == 'work_custom')
def get_work_custom(msg):
    uid = msg.chat.id
    try:
        value = float(msg.text.strip())
        user_state[uid]['data']['work_hours'] = value
        user_state[uid]['step'] = 'sleep'
        user_state[uid]['waiting_for'] = None
        send_msg(uid, "А сколько часов спал?", get_sleep_keyboard())
    except:
        send_msg(uid, "Ошибка! Напиши число, например 3.5")

@bot.message_handler(func=lambda m: m.chat.id in user_state and user_state[m.chat.id]['step'] == 'sleep')
def get_sleep(msg):
    uid = msg.chat.id
    text = msg.text.strip()
    
    if text == "Другое":
        user_state[uid]['waiting_for'] = 'sleep_custom'
        send_msg(uid, "Напиши сколько часов спал (например 7.5):")
        return
    
    try:
        value = float(text)
        user_state[uid]['data']['sleep_hours'] = value
        user_state[uid]['step'] = 'comment'
        user_state[uid]['waiting_for'] = None
        send_msg(uid, "Хочешь добавить комментарий?", get_comment_keyboard())
    except:
        send_msg(uid, "Ошибка! Нужно написать число")

@bot.message_handler(func=lambda m: m.chat.id in user_state and user_state[m.chat.id].get('waiting_for') == 'sleep_custom')
def get_sleep_custom(msg):
    uid = msg.chat.id
    try:
        value = float(msg.text.strip())
        user_state[uid]['data']['sleep_hours'] = value
        user_state[uid]['step'] = 'comment'
        user_state[uid]['waiting_for'] = None
        send_msg(uid, "Хочешь добавить комментарий?", get_comment_keyboard())
    except:
        send_msg(uid, "Ошибка! Напиши число")

@bot.message_handler(func=lambda m: m.chat.id in user_state and user_state[m.chat.id]['step'] == 'comment')
def save_all(msg):
    uid = msg.chat.id
    
    if msg.text == "Пропустить":
        comment = ""
    else:
        comment = msg.text
    
    data = user_state[uid]['data']
    today = datetime.now().strftime("%Y-%m-%d")
    
    db.save(today, data['mood'], data['work_hours'], data['sleep_hours'], comment)
    
    del user_state[uid]
    

    if data['mood'] == 1:
        emoji = "😢"
    elif data['mood'] == 2:
        emoji = "😕"
    elif data['mood'] == 3:
        emoji = "😐"
    elif data['mood'] == 4:
        emoji = "🙂"
    else:
        emoji = "😊"
    
    result_text = "✅ Сохранено!\n\n" + emoji + " Настроение: " + str(data['mood']) + "/5\n💼 Работа: " + str(data['work_hours']) + " часов\n😴 Сон: " + str(data['sleep_hours']) + " часов"
    if comment:
        result_text = result_text + "\n💬 Комментарий: " + comment
    
    send_msg(uid, result_text, main_kb)

@bot.message_handler(func=lambda m: m.text == "📊 Статистика" or m.text == "/stats")
def stats(msg):
    uid = msg.chat.id
    week_ago = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
    rows = db.get_week(week_ago)
    
    if not rows:
        send_msg(uid, "За последнюю неделю нет записей. Добавь первую через /add")
        return
    

    total_mood = 0
    total_work = 0
    total_sleep = 0
    work_count = 0
    sleep_count = 0
    
    for r in rows:
        total_mood = total_mood + r[0]
        if r[1] is not None:
            total_work = total_work + r[1]
            work_count = work_count + 1
        if r[2] is not None:
            total_sleep = total_sleep + r[2]
            sleep_count = sleep_count + 1
    
    avg_mood = total_mood / len(rows)
    
    if work_count > 0:
        avg_work = total_work / work_count
    else:
        avg_work = 0
    
    if sleep_count > 0:
        avg_sleep = total_sleep / sleep_count
    else:
        avg_sleep = 0
    
    text = "📊 Статистика за неделю\n\n😊 Настроение: " + str(round(avg_mood, 1)) + "/5\n💼 Работа: " + str(round(avg_work, 1)) + " часов в день\n😴 Сон: " + str(round(avg_sleep, 1)) + " часов в день\n📝 Записей: " + str(len(rows))
    
    send_msg(uid, text)

@bot.message_handler(func=lambda m: m.text == "📈 Аналитика" or m.text == "/analytics")
def analytics(msg):
    uid = msg.chat.id
    

    best_days = db.get_best_days()
    sleep_data = db.get_sleep_impact()
    work_data = db.get_work_impact()
    
    text = "📈 Подробный анализ\n\n"
    

    if best_days:
        text = text + "🌟 Лучшие дни:\n"
        for day in best_days:
            text = text + "📅 " + day[0] + " → настроение " + str(day[1]) + "/5"
            if day[4]:
                text = text + " (комментарий: " + day[4][:30] + ")"
            text = text + "\n"
        text = text + "\n"
    
  
    if sleep_data:
        text = text + "😴 Как сон влияет на настроение:\n"
        for s in sleep_data:
            text = text + "" + s[0] + ": настроение " + str(s[1]) + "/5 (записано " + str(s[2]) + " раз)\n"
        text = text + "\n"
    
   
    if work_data:
        text = text + "💼 Как работа влияет на настроение:\n"
        for w in work_data:
            text = text + " " + w[0] + ": настроение " + str(w[1]) + "/5 (записано " + str(w[2]) + " раз)\n"
    
    if not best_days and not sleep_data and not work_data:
        text = text + "Пока мало данных для анализа. Запиши больше дней!"
    
    send_msg(uid, text)


@bot.message_handler(func=lambda m: m.text == "💡 Инсайты" or m.text == "/insights")
def insights(msg):
    uid = msg.chat.id
    
    monthly = db.get_monthly()
    optimal = db.get_optimal()
    recs = db.get_recommendations()
    
    text = "💡 Что я понял про тебя\n\n"
    
    if monthly and monthly[0]:
        avg_mood, max_mood, min_mood, good_days, bad_days, total = monthly
        text = text + "📅 За последний месяц:\n"
        text = text + " Среднее настроение: " + str(avg_mood) + "/5\n"
        text = text + " Самый хороший день: " + str(max_mood) + "/5\n"
        text = text + " Самый плохой день: " + str(min_mood) + "/5\n"
        text = text + " Хороших дней (4-5): " + str(good_days) + "\n"
        text = text + " Плохих дней (1-2): " + str(bad_days) + "\n"
        text = text + "\n"
    
    if optimal and optimal[0]:
        text = text + "✨ В твои лучшие дни ты спишь " + str(optimal[0]) + " часов и работаешь " + str(optimal[1]) + " часов\n\n"
    
    if recs:
        text = text + "💪 Мои советы:\n"
        for r in recs:
            text = text + " " + r + "\n"
        text = text + "\n"
    
    text = text + "🤔 Подумай над этим:\n"
    text = text + "Что было общего в лучшие дни?\n"
    text = text + "Высыпаешься ли ты?\n"
    text = text + "Не перегружаешь ли себя работой?"
    
    send_msg(uid, text)


@bot.message_handler(func=lambda m: m.text == "📜 История" or m.text == "/history")
def history(msg):
    rows = db.get_history(10)
    
    if not rows:
        send_msg(msg.chat.id, "История пуста. Добавь первую запись!")
        return
    
    text = "📜 Последние записи:\n\n"
    
    for row in rows:
        date, mood, work, sleep, comment = row
        
        if mood == 1:
            emoji = "😢"
        elif mood == 2:
            emoji = "😕"
        elif mood == 3:
            emoji = "😐"
        elif mood == 4:
            emoji = "🙂"
        else:
            emoji = "😊"
        
        text = text + "📅 " + date + "\n"
        text = text + emoji + " Настроение: " + str(mood) + "/5\n"
        text = text + "💼 Работа: " + str(work) + " часов\n"
        text = text + "😴 Сон: " + str(sleep) + " часов\n"
        if comment:
            text = text + "💬 " + comment + "\n"
        
    
    send_msg(msg.chat.id, text)

@bot.message_handler(commands=['clear'])
def clear(msg):
    db.clear()
    send_msg(msg.chat.id, "✅ Все записи удалены")

if __name__ == "__main__":
    print("Бот запущен!")
    print("Жду сообщения...")
    try:
        bot.infinity_polling()
    finally:
        db.close()