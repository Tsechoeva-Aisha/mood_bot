import sqlite3
from datetime import datetime, timedelta

class Database:
    def __init__(self):
        self.conn = sqlite3.connect('mood.db', check_same_thread=False)
        self.cursor = self.conn.cursor()
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS log (
                date TEXT PRIMARY KEY,
                mood INTEGER,
                work_hours REAL,
                sleep_hours REAL,
                comment TEXT
            )
        ''')
        self.conn.commit()
 
    def save(self, date, mood, work_hours, sleep_hours, comment):
        self.cursor.execute('''
            INSERT OR REPLACE INTO log (date, mood, work_hours, sleep_hours, comment)
            VALUES (?, ?, ?, ?, ?)
        ''', (date, mood, work_hours, sleep_hours, comment))
        self.conn.commit()
    
    def get_week(self, week_ago):
        self.cursor.execute('''
            SELECT mood, work_hours, sleep_hours 
            FROM log WHERE date >= ?
        ''', (week_ago,))
        return self.cursor.fetchall()
    

    def get_best_days(self, days=30):
        start = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
        self.cursor.execute('''
            SELECT date, mood, work_hours, sleep_hours, comment
            FROM log WHERE date >= ? ORDER BY mood DESC LIMIT 3
        ''', (start,))
        return self.cursor.fetchall()
    
    def get_sleep_impact(self):
        self.cursor.execute('''
            SELECT 
                CASE 
                    WHEN sleep_hours < 6 THEN 'Меньше 6 часов'
                    WHEN sleep_hours < 7 THEN '6-7 часов'
                    WHEN sleep_hours < 8 THEN '7-8 часов'
                    WHEN sleep_hours < 9 THEN '8-9 часов'
                    ELSE 'Больше 9 часов'
                END, 
                ROUND(AVG(mood), 1), 
                COUNT(*)
            FROM log WHERE sleep_hours IS NOT NULL
            GROUP BY 
                CASE 
                    WHEN sleep_hours < 6 THEN 'Меньше 6 часов'
                    WHEN sleep_hours < 7 THEN '6-7 часов'
                    WHEN sleep_hours < 8 THEN '7-8 часов'
                    WHEN sleep_hours < 9 THEN '8-9 часов'
                    ELSE 'Больше 9 часов'
                END
        ''')
        return self.cursor.fetchall()

    def get_work_impact(self):
        self.cursor.execute('''
            SELECT 
                CASE 
                    WHEN work_hours < 2 THEN 'Мало (0-2 часа)'
                    WHEN work_hours < 4 THEN 'Нормально (2-4 часа)'
                    WHEN work_hours < 6 THEN 'Умеренно (4-6 часов)'
                    WHEN work_hours < 8 THEN 'Много (6-8 часов)'
                    ELSE 'Очень много (8+ часов)'
                END, 
                ROUND(AVG(mood), 1), 
                COUNT(*)
            FROM log WHERE work_hours IS NOT NULL
            GROUP BY 
                CASE 
                    WHEN work_hours < 2 THEN 'Мало (0-2 часа)'
                    WHEN work_hours < 4 THEN 'Нормально (2-4 часа)'
                    WHEN work_hours < 6 THEN 'Умеренно (4-6 часов)'
                    WHEN work_hours < 8 THEN 'Много (6-8 часов)'
                    ELSE 'Очень много (8+ часов)'
                END
        ''')
        return self.cursor.fetchall()
    
    def get_monthly(self):
        self.cursor.execute('''
            SELECT 
                ROUND(AVG(mood), 1), 
                MAX(mood), 
                MIN(mood),
                SUM(CASE WHEN mood >= 4 THEN 1 ELSE 0 END),
                SUM(CASE WHEN mood <= 2 THEN 1 ELSE 0 END),
                COUNT(*)
            FROM log WHERE date >= date('now', '-30 days')
        ''')
        return self.cursor.fetchone()
    
    def get_optimal(self):
        self.cursor.execute('''
            SELECT ROUND(AVG(sleep_hours), 1), ROUND(AVG(work_hours), 1)
            FROM log WHERE mood >= 4
        ''')
        return self.cursor.fetchone()
    
    def get_recommendations(self):
        recs = []
        
        self.cursor.execute('''
            SELECT sleep_hours FROM log 
            WHERE sleep_hours IS NOT NULL 
            GROUP BY sleep_hours 
            ORDER BY AVG(mood) DESC LIMIT 1
        ''')
        sleep = self.cursor.fetchone()
        if sleep:
            recs.append(f"Лучше всего спать {sleep[0]:.0f} часов")
        
        self.cursor.execute('''
            SELECT work_hours FROM log 
            WHERE work_hours IS NOT NULL 
            GROUP BY work_hours 
            ORDER BY AVG(mood) DESC LIMIT 1
        ''')
        work = self.cursor.fetchone()
        if work:
            recs.append(f"Оптимальная нагрузка {work[0]:.0f} часа")
        
        return recs
    

    def get_history(self, limit=10):
        self.cursor.execute('''
            SELECT * FROM log ORDER BY date DESC LIMIT ?
        ''', (limit,))
        return self.cursor.fetchall()
    

    def clear(self):
        self.cursor.execute('DELETE FROM log')
        self.conn.commit()
    
    def close(self):
        self.conn.close()

db = Database()