import os
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup
from dotenv import load_dotenv
from telebot import apihelper

load_dotenv()

TOKEN = os.getenv('BOT_TOKEN')


apihelper.proxy = {
    'https': 'http://TmTaV5:6RJ8tR@68.209.61.83:8000',
    'http': 'http://TmTaV5:6RJ8tR@68.209.61.83:8000'
}


main_kb = ReplyKeyboardMarkup(resize_keyboard=True)
main_kb.add("📝 Записать свой день")
main_kb.add("📊 Статистика", "📈 Аналитика")
main_kb.add("💡 Инсайты", "📜 История")

def get_mood_keyboard():
    markup = InlineKeyboardMarkup(row_width=5)
    for v in range(1, 6):
        if v == 1:
            emoji = "😢"
        elif v == 2:
            emoji = "😕"
        elif v == 3:
            emoji = "😐"
        elif v == 4:
            emoji = "🙂"
        else:
            emoji = "😊"
        markup.add(InlineKeyboardButton(f"{emoji} {v}", callback_data=f"mood_{v}"))
    return markup


def get_work_keyboard():
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    markup.add("1", "2", "4", "6", "Другое")
    return markup

def get_sleep_keyboard():
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    markup.add("6", "7", "8", "9", "Другое")
    return markup

def get_comment_keyboard():
    markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    markup.add("Пропустить")
    return markup

user_state = {}