import requests

apihelper.proxy = {
    'https': 'http://TmTaV5:6RJ8tR@68.209.61.83:8000',
    'http': 'http://TmTaV5:6RJ8tR@68.209.61.83:8000'
}

try:
    r = requests.get('https://google.com', proxies=proxies, timeout=10)
    print("✅ Прокси работает, интернет есть")
except:
    print("❌ Прокси не работает")